import 'package:flutter/material.dart';
import '../screens/screen_export.dart';
//Este no
class AppRoutes {
  static String initialRoute = '/Home';
  static Map<String, Widget Function(BuildContext context)> routes = {
    '/Home': (BuildContext context) => const HomeScreen(),
    '/Error': (BuildContext context) => const ErrorScreen(),
  };
  static onGenerateRoute(settings) {
    return MaterialPageRoute(builder: (context) => const ErrorScreen());
  }
}
