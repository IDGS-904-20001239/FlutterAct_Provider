import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class UtilProvider extends ChangeNotifier {
  static final UtilProvider rtp = UtilProvider._();
  final storage = FlutterSecureStorage(); 
  UtilProvider._();

  Future responseHttp({required String urlBase}) async {
    var response = await http.get(Uri.parse(urlBase));
    return response;
  }

  Future checkSession() async{
    Map<String, String> allValues = await storage.readAll();
    if (allValues['inSesion'] == '1'){
      return 1;
    } else {
      return 0;
    }
  }

  Future saveStorage(
    {required String usuario, required String password}) async{
      await storage.write(key: 'Usuario', value: usuario);
      await storage.write(key: 'psw', value: password);
      await storage.write(key: 'inSesion', value: '1');
      return 1;
    }

    Future clearStorage()async{
      await storage.deleteAll();
    }
}