import 'package:acti_provider/providers/pokemon_providers.dart';
import 'package:flutter/material.dart';

import '../themes/app_theme.dart';
import 'package:provider/provider.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState(){
    Provider.of<PokemonPorvider>(context,listen: false).getPokemons();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    final pkprovider = Provider.of<PokemonPorvider>(context);
    List pokemons = pkprovider.pokemons;
    print(pokemons);
   return Scaffold(
        body: CustomScrollView(slivers: [
          SliverAppBar(
          backgroundColor: AppTheme.primaryColor,
          expandedHeight: 250,
          floating: false,
          pinned: true,
          flexibleSpace: FlexibleSpaceBar(
            centerTitle: true,
            title: Container(alignment: Alignment.bottomCenter,
            width: double.infinity,
            child: const Text('Pokedex'),),
            background: const FadeInImage(
              fit: BoxFit.cover,
              placeholder: AssetImage('assets/loading.gif'), 
                              image: AssetImage('assets/pokemon.png')),
          ),
        ),
        SliverGrid(delegate: SliverChildBuilderDelegate((context, index) {
            return Container(
              decoration: BoxDecoration(color: Colors.white,
              borderRadius: BorderRadius.all(Radius.circular(10))),
              child: Column(
                children: [
                  FadeInImage(
                  fit: BoxFit.cover,
              placeholder: AssetImage('assets/gif.gif'),
              image: NetworkImage( 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEBUTExMWFhIVFxYYFxgWFRgVFRcYFxUXFhgWFxgYHSkhGholGxcZIjEhJikrLi4uFyIzODMtNyktLisBCgoKDg0OGxAQGi0lICYtLy8uLS4tLS0tLS01LS0tLS0vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABQYDBAcCAQj/xABEEAACAQIDBQUEBwYEBQUAAAABAgADEQQSIQUxQVFhBhMicYEHMpGhI0JSYnKCsRSSosHR8DNjc7MkNMLh8RUWk7LD/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAMEBQIBBv/EADQRAAIBAgMFBgYCAgMBAAAAAAABAgMRBCExEkFRYfBxgZGhscEFEyIy4fEU0UJSM2LiI//aAAwDAQACEQMRAD8A7jERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAESB7SbfXDLlWxrMNAdyj7TdOQ4/Eh2S2lWxFAvWW3jIVgLB1sNbedxfdpONtbWzvO/ly2NvcetqbYanWNNQmiK3izali4AuNwGTkb34W1rG08XVrVVLlCgHNgQ3+Wt7Lb7RJY3O4WEk+3GFqBqdWlbX6NwRcWAZ0I5G+Ycd40lMFIZ1eoBVYG5VyQhFiLAa2334m4F+lHETn8zYcrLrgXsPCHy9tRu+uJdcD2hemuWorVANxUjvPI5iA3ncHzOp9jt3hc5Qhgw3gvQv8O9uPWUqlXqpuYOOTXB9G19AfjFbaSBld1yOhBDkEZbEEePVSLgeEkg8ROKeJqLJ5rsz9V1vO6mFpvNZPhfL0fl4HT9l7WpYhM9JrgGxG4jl5g8CNDwMkZynZm06lLEPWTKoc3yqPAb6tpwu1zvOpuN5Ev+yNtpXAHuVPsMQSbbyhGjL8xcXAOku0q8Zu18/C/NdZeF6VWhKGdsvTk+syXiIk5AIiIAiJ8BgH2IiAIiIAiIgCIiAIiIAiJ4dwASTYDUk6ADmYB7ld7QdohQPd08rVR7xb3KelxcDVmI1ygjTUkaXiO1PbinSXJSbxNoHAzE/wCkv1j973Rcb5z+pWr1f8pTr9uqb6km+gJ43uZG3OeVJd+5f2+zvO26VLOs7cFvfduXN2uXHEdscQb/AEqKOaoB/wDctIqp2uZ2CnFEk6DK4W55fR2F+kgf/TaZ1f6Q83JY+g3D4SO7Q01CqAoAAJIA4fW+V52sBUl91R93S9CvP4vShnCirc3n7+rRcuzuFXEYxKLXZLNUqEk3a3AnqxUHkNOU6tTQKAAAABYAaAAbgBOReznaRWvSLHXMaLk7/ELL6lhT+JnYZDQhsJxeqbT7S7iKm24yWjSa7GR22sKatB1W2fRlvoMynMBfgDa1+s57isKQT4SCD4lIsynkR/fMXGs6nI7aWyaVe2cEMNA6nK46X4jobjpOcRh/m2admj3D4j5WTV0zmJE+Wl1xnZMnVKgPR1sT+dNB+6ZUMTSZGZXUoymxBIOuttR0F/Ig8Znzozp/cjRp14VPtZrUaeUWG4bhyHL0/S0m6XZ3FCklRclRWVH8BIa5F7hW5cw1+QkPLr7PQ4wjBnzBajKgJuUQAWUk9De3AH0EuHhGpJqRFiZzppOJrbB7Q1O8WjUuxLBbNpUUn5m28hhe1zc2tLpMRoJmz5Vz2tmsM1uV99plmjTi4qzdzNqSjJ3SsIiJ2cGHEUs6MtyuZSMymzC4tcHmJQNjY84PEmnUstMtkqfVRW+pV6A3Gv2WBO6dFnK/aDikGKqXK92KdNHvuz3YnzJV1HWwEgr3VprVPxuWMPaTcHo14W3nVInKexfbVaYFFmapRXdcEVaY6B7Fk/ThwE6Ts/aVGuCaVRXtvAPiW+tmU6qehAkkZqWW/hvIp03HPVbms0+9G7EROzgREQBERAEREA09qY0UKL1TrlFwN2Y7lUdSSB6zkm3e0VetVNLPmYWJ4Uqd91kGhbiL3IuDeWv2jbYCKKYNwlncDix0pJ53N7fgMoOAwxQEsb1HOZz1PLoN05hT+dUaf2rXm+HctUeV6/8AHpJx++WnJLf2t5Lve49YbCBCWJLOd7tqx/oOgmzETRStkjDbbd3qJC7UOasE/AvxYA/IyakS6/8AEE/ZBPS5XKo/iE6W84nuXNG5giUrmxtnFwRvWoh3jrrf8s7XsjHCvQSqNMw1HJgcrL6MCPScRxpsA/GmQ3w0P8JInSewGOFqlEsLkiogvqdArgdAQD+eZlVbFflJea/Bv4WXzMLzg7dz088u4ucRE6PRKR20wg70NYXemSPxU2UMfgaY/LLvK32wTw0m452X0KFj/tj4Svilek/EsYV2qxKKBLX2Br2arT4MFceY8Ln4GnKxWp2a3CSPZrFd3iqZ4Mch/P4QP38nwmdh52qJ9ZmjiIbVOXWh0mIibJjCIiARXaLaow2HaobZtyA7ixBOvQAFj0Uz8/baxzYhyxJIFyt95JJJZurG56A253uPtO24atXulPg1UfhUjO352AUfdS/GUvuDa5Hl8bSXDU1OTqPRZL3fsu8pfEa7pxVGOrScuzVR933LjfXpDiN4OhG8dQZcNhbWq0npVD766g7s672QnhcDUbuI3aVvB0/Eo56fEWlgakLW4aeltxElxOHU4ritHw/BVwONlSnJ6xeq4+17HatnY1K9JatM3Rhcc+RB5EG4I5ibc5B2Y7SVMJVysC1Jzqo3NYe8nKoANVO8DpcdT2fjqdZBUpMGU8RwPEEHUHodZTi3o1ZrVGy0rKUXeL0fWjW9G5EROjkREQBNLamOWhSaq25RoOLE6BR1J0m7Oc+1TabIuVWsUUED79RmRWPUAG34jOJycVlru7TunFSlnpv7FmynbQxZxOKZ2NwjEsRuaqdD6KPCOVrcJnAkPsey0dTYakk/zPlaXzs52NeuBVxBanSOq0x4arDmTvpr0Hi8pdhGNGGzf8ve+uRkVJTxNVyS18EtEutc3bUrLuBvIHmbQjg7iD5G86zg+zWCpDwYalcfWZA7+rvdj6meNq9msNXQr3a03+q9NQrqfTePunQzz564Hf8AClb7l4e/4OWSNxIswHF3HwQA/raTW0sC9Cq1KoLMvLcwO5l6H+o4GQtdr4lRwRb+puT8ssmTuUpKzs9369zacggg7jp6TUO03w+VSudBbKwYq4tu/MPtXE2QZp7SS9M8bf3pIqlGFVWmizRxFTDtypu3HemufV/MufZ72i6qjnON1n8NX8rHSp5HXm06Dsva1HELem9yN6nR181Oo89x4T80snA6iTOxtv1KDLqxUHQgnOn4Tvt0/wDErTozpr6fqXB69z39/iaFLF0qrtP6XxX296za7VdcbH6Old7Y/wCHR/1v/wAK0r2zu37Cmuen3pO51YJcfeFrX6jToJK7a2kmIw+GqJcZ3ZrG11y06iMDY20ZgOO+VatSMqUrPc/QvU6U4VY3W9epX8ZTut+Img5IBK+8NV/ENVPxAksZGVkytb4THi+BsSXE6rh6wdFdfdYBh5EXEyyp7K2/ToYGialyQTSCrYse7uAdSABkCm55jmJr43t/RVSUpOSOLlUQebAsflN11YJXb5mEqNRuyV9xdJV+0faWlTptTpOGqm63U3CcCS27MOW+9rzne3e31SrdS5Kn6lMZKZ6EnVhz1IPKVPFbWqOCtwqkWsvLlmOvwtPdmrPKCtzeXgtTl1KFLOpK74Rz8XovEyNWNesWG5yMvRBoo+GvmTJPadJVQEcwPSx/naanZ+n4ieQ+Z/7Te22bUfUf1/lNKEVBRhHRZHz1Scqkp1Jayb69u4iKbWIPIgyzSqlpZcK+ZFPMCSTK+H3n2rTDKVIuD/5BHIg636TFhdp1qFQDMysSBTqqbEm/hSoBvF+B0PETZmtj6eak45qR1BI3jrK1ajGqrPXc9668zRw2Knh5XWa3rc1/fB8eWR2zZmMFajTqjc6q1uRI1HmDcek3JTfZntDvMIVO9GvbkHGc/wAecekuUpxd1c2Jx2ZNCIidHInHPa+/0zDmaQ9BTdh852Ocj9ruEdsQgUXNTuAvVy9SmB8SvxnMtY9q9T3/ABml/rL0Zg9lnZv9ob9pqi9GkbIp3NUGuvNV09SPskTscjthbKTC4alQT3aagX+029mPVmJJ85IyScnJ3IaNJU47KERE5JSq9utjd9Q71B9LRBOg1ZN7rpvIHiA5i3EzjtFr4h+V9DfeMi6jpP0ZOZVuxgqbRakRah/iMQLE0ibimGG4F7r+FTxk9Kdk0yliqG20463KvsrZuJxh/wCFol0BsajnJSBG8Zjq3XKDJmv7O9olT9Lhibbr1B6A5J1ahRVFCIoVFACqoAUAbgANwla29tksWo0iQBcVHBsSdxRCN1txYbtw1uRDVxPy47TyRPSwKm9lZvta9PycU2jsevRqtTemc678pzj4pcX6bxxmOjsjEN7tFz5oVHxawnW8BgK1ZbUUXu00DM2SncEgqmVTe1tTa19L3BAi+02Kq4E0+/pZlqXs1J8ygjepzhbGxv8AHkZXWNxM1eFPrsTRYfw3C08p1Xl2erTIfYHZhkpk1qpVibinTykKSNczMDfyWwvfU3kvgqApPlNQte+QEABbgFwOZbICeH0Y0Gt/GA2ylWmrqDY8Da4INiD1Bm8ih8rW1Gq33gkFf0J+MyatSpKT29Xru6zNqjTpxhFQ0Wmd8v0zM9OwHUfzmriqGYdRJDHsFy3IAA4mw+c1UqqdzAnoQf0kbVmSxzRWcXh6veHLZlsLKWK2O5iuhGoCct2+VntAaoqZaiMiLuDbj98kXU8t+nqZfsaLNeYV2vaotG+aq5AVFVmY36KDYdTwBMt4avKE01HafWfSKeLw8alNxc9lccvD8LXmsjmdNgxyqQzHcFOYn0Gs+ZhfePjOzHAYimpd6JRBqxBQkD7RCkm3M8OOlzPezatKm5L0kem58YKKxudM401PMcR1Fjor4i1JRqQ2U+f4/q28ypfCU4bVOptNcvz+9xzrYK2pk8/6Cee0DeBBzYn4KR/1TpHabslRWia+EQLYZmp0/wDDdLXLU1GgIGvh0YXFrkEcv7Q1AWSx0yk9LEjX5TThJS0MStSdLJ+Jp4PCVK9VKVJS1R7Kqjid/oALkngBOiYrsPisNRUoy1wB40RStRTxy3P0g+B6HcJn2Ydl/wBno/tFVfp6y+G41p0jYgdGbQn0HA3sHazaj4agHQDMzhfELixDE8RyleriNltrReZfwuAU0oP7npyOUUq6tu4aEHQg8iDuMx4trow6EfKTuz+zq4ukzLVyYsMFpk3ZXVUvlqD7NhbNvFhvHhNW2wtWkzUayGnVGpB48QVPFTY6iSUKyqxUllyIMdhJYSpKEndcbWv/AF1zLb7HsVapUpcGUn91gR/uP8J1ecR9luIy49R9oZT/APHXb9VE7dK0spyXN+efuX6Lbo02/wDVeX0+wiInhIJUO3mGt+z4oLmFCqpcfczo9/RkA/NLfE8auj2Ls7iIiengiIgCaG09opQTMx1Nwqj3mIF7D+p0HGb8g+0ewv2lUIqNTqU75WG4hiuZT55RrwOtjuPM9qz2deZ1HZv9WhXm25Xq3DVMpHvLT8IHKx961uNxfkN00qgsugJAtcLoxUEZlU3FmK3AN95E97SrpSrDD2s9FKVIAA3qMyq2YHjmZrXOtwb75s7cwAwndM9a4qXU3AUBwAbrbcu/fc7tZkVadRyk73UePsuBrUqlNRikrOXDXvfEuWzHpGiho27rKMgUWAUCwAHC263C1pV/aXhBXw9Kh9Zqoa/FVVWDuP3gPNhJjYGJVMEKjeFB3rk/d7x2zDmCNR5ys4nFNVdqj6M3D7Kj3U9L+pJPGX6+JdOCkvuenL9etihRwyqzcZfatefLv9LkZhNlU6YCoLIOG+55k/rzk/sfAGoM58NPTKbeJhzUHcu6zHfwFrGa+zcF3rnMPo0tm+8x1CeVtT0KjcTLSjaTOpR2ntSLmIrbP0Qy60RhTA0lN1Rc32iMzfvNcz7XwtNxZ0Vh1UG3lymW89TuTuyokU3tHss0vGhJpgag6sg4kHey+eo11O4aXsy2Llx+Jqt4sqr3bHW4qk/NRTy35ect21TukJsFv2XGKg0pVgVHJTe4XyDGwHKrb6smw09iWW/J9dp7V/8ApC0tVmvBrvyZf5S9ubOShUHd6K4JCcFIIvl5Kcw04G/PS6TndLG/tWKdFN6ve1Us2hVabsNRwAUD1PMyxjM4bNrtvLtPMJlPavZJZ9htYDaNWjcIQUOuVgSAeJUggrfiNR0BJJgNmdlFxO01dlUUFXvGphgQpzH6G28oXuwNgMvh3giSONpFWZHyq1NxmPvBNxL6Wv8ARtm4b7G2s3sPsvEpjURVBSmVfvwMq5DbOls18xF10uDv4WEOEq14vZ1Wj0uuv0SYyhh52k8n9y1s+v2i9Ssdu6ObDLyFRb9Lqyg/Ej4yzyMx+WrekRdb+O+7dfKOZ1B6SziWlSld7vPcV8PPYqxlwdyD7L0CuGANlvU94WOmni046elrzD7U9krVwLVgo73D2cNxyXAqC/LLdrc1Ej8Bj3o4gK2bul7wAKLgl6ly1vW0ugwQqYd6NQeGotRWXQ2V7jKbabjw0lX4dUavlzv7E/xKi225f5X69zivs3Nsch5VKY+Iqr+jTvc4h7OsIy4pEI8YrlW86KEt6XvO3zQ2rzm+fsilGGxSpr/r7tiIiegREQBERAEREARK5tHtfQp6Jeq33LZP3zoR1W8gj7Qqub/lkt/rG/8AtyN1oJ2uSqhUaukXHGbJoVXV6lJGdPdYjxDpffbpunrH4CjVymqiuEOYZtQDzsdOHGVrB9v6LaVKVROoKuo/Q/KY9q7aGJsKRPcDiQV7xhzBAORTz3nyF+Z14QjtXueww85SUWrGXb21hWy0qQvRBDM+4NlIKKg4rcA5tBoLXBNol2Cgk7gCT5DUz0ZhxDaC/ulkDfhLqG/hJmPVqurO8jXp040oNLt8i17Jwvd0VUjxEZn/ABNqR5DcOgE3bTytQHWfS0kM3tPLmEn28wYisFEA0tovdrcpCbbVu5Z0/wASl9KnQpr+l/W03aj3N54rgZGB3FWv5EG/yklrC5daFYOiuuqsAwPQi4mFcFTFU1QgFQgKWG8gbr87czKX2A2+lPD0cNWYr4E7pm92zKv0Zb6pDGwvYWZQJf5qQmpq6K04OEtllZxfZKnVxT12q1AKhUtTWwVsqKlmOpOijdaWaInqik21vPHJtJN6CVHaG1AuIFSzLRylblSv0rZraEa3CDXylukFjcBTrI9NxdQ5tY6g79D0JIlPH/8AGluuWMLKEZ3msiO2zs5Uol0JVqbl72zHxNcgfmIPpNzs1t5sSzpUp5HQKePiHHQ7uBt94Taq0FamUfUZbNrwtv8AlNDYzCtiXqAWWmBYj6zEFST0sN3QGUcFVlGoorfr4FiUozoy2ldrR+3O+fVzU7HbIy4nFYkoVBrV1phgQTmrFqj2PAkLbyMuURNpKxnybbuxERPTwREQBERAMdWoFUsxAVQSSdAABcknlOc9oNvPiSVF1ocF3Fx9qp/JeHHXdJ9uNqXYYZDoLNVtxO9EPTcxH4eFxKsFlDFV89iPf/Ro4TDpr5kl2f2YHZ9bAdP7uP7M0ylQk3QA/iFvlc/KSLTE9YCU0+CL0lxZr0cCzuqFgL6tlvcIpGbxHibgDS+t+Et4pBKagADcABoAoFgAOW6V/YVUF2Y/WIUfhS4t+8z/AClixlYGwHDjOZvW+48S0sa5mhtmpamw6EnyGs3KtUKLmRtSmarBOLkA9Fv4z6Lf1tznFNXkjqbtF9hZ0rspNjNqntA8RNYmfJZMo322gvIzRr1mc9J8iAYys09qvahU5spUeb+AfNhJAiRWMrB6oQe6hJbqw4emvqekOVlc7hT25JGuMAuW3G1unlblLJ2W2yQFoVib7qbn/bY8/sniNN48UPPLoDv4+nrcag9ZDRrypSuu8vVqMasbM6PEhezu0e8Qo7Xq07ZibXZTfK5tzsQd2qnQC0lMTiUpjM7qi82YKPiZtwkppSjozElFxbi9xmle7RYxMLRaoWAJzFVI3sbsbm4so1JPAegmttftnQpKe7+kbn7tMdSx3/lB8xILYeBq7RxH7RibmhTIspFldhqFy8EGhIPS9yTlhq7FX6LX9uuraksYSh9Usl69cf0SfZ3ZGIrKtavUyrUGY0wCrMpOYK99w5jfY2MuSiwsNwnqJJSowpK0FY8rVp1ZXl5KwiIkhEIiIAiIgCIiAci7UM6Y+uG3lgwvxRlGUjoLFfNDI44tp1DtRsBcWg0XvV90sNCOKk7xzBGoI5XB53X2WqOUdWVl3qXe4/i3dd0oVqH1X4l+jibRUeBHNUJ4zE1UAE78oJNtSABc7pK/slP7APn4v1nnF0Q1M0wP8SyWGmjaNbyXMfScKCWp267eUUecPRKrTH1ksTyJsQ3zYmSLY4gHTy5zWRswzc9fjrPrSm83mXVloeMTiwLFjqd1z/dgL75N7JoKgzZgXYanhbeFXp13n0AETsgDNVN7tmUW4hQisq2328RPmTJRNnFvdo1NeKU6iX/MoH6yxCllkihWqtycdxJkzxea9LYOKPurWUfeqUyP4yzSRp9msSVsa6oeYHen4ZUEljRnwK+2jCGmHEYpKYu7BRwubX6AcT0E3avYxiP+dr5uq0gnwpor/wAfGQ1fsTiUJKmnU65iKh884/6jO/40t558xEXjO0gYlKYdU0u9vGfJPeQcMxF99raNPOFrjRlIIHLd5dJ6xWw8Quj4ep+53g+KXEj6mzWF2Wmy1ANPCy3I1CkciRa1uMjnhm9CxSxMYbiyU6gYXExftgDFSOAN/j/frI5aotmB8JF79DPHfqbnMDbebjTz5Sgos0WzFjMey4gsjOAUtZGdb2YasEOutxrut1mCpXqMc1gD9pt/8z8bSd2HsM4qo5FRVAVN92Yi7G4UW08Vr34bpc9ndl8NRscneOPrVLMQeYW2VT1AvNGjh1KCb0M6tiXCbUbe5Rdh9ma2JYMbinv7xhYW/wAtT7x5HUdeB6ZgcIlGmtNBZFFgP1JPEk6k8SZtRL0IKKsilKTk7sRETo5EREAREQBERAEREATSx+zqVcWqoGtuOoYfhYWI9DN2IBXf/Z2Fvr3hHLvWHzBv85E7Z2OlOvSp0KN2KVHF3LG65QSWcnKArWv98DlLxIvGYeq9bw2FM08pf6y+K7BV4lhl13DLx3SOdKM1ss7hUlB7SOdNSurVaYZktndQAO7BNmYg2IN73XU3VrDQzC6X4GwK5iPdFz4Qx6kf3fW3UNlKr4jCUnIZ2713NmdEqIQDuAN6ne5QeNzrYie17NjD06tNQ1enWKjxhS6EhaZBCqAaWVRwuNb3BJWqsCss+P8A5/JbeNeeXD8/g3uxeGZMNdhbvHLj8Ngqn1C38iJYIiXYrZSXApyltNviIiJ6ciIiAIiIBz7H9lsRTJ7tRUp8CpAcD7ytYaDTQm/IbpGVtlsKZqEM1RQpqUSgDoGNgVBGY2JAO8HeN2vVJq4rCJUy5luVIZTcgggg6Ea201G47jK/8Wnnlr5dhYWKqZK+nn2lAwmBq0qlOtTfOoNiyLmyuVK5Ct/FTYkDncW3lTL3szFGqmYqVYEqwsRYjlmANjv1F9dbG4jF7NpVLkrZj9ZfC+nAkbx0Ok3pNGEYq0VZEMpym7yd2IiJ0ciIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgH/2Q==')),
               Text('Charizard',style: TextStyle(fontSize: 12),),
               Text('#006',style: TextStyle(fontSize: 10),)
                ],
              ),              
            );
        },
        childCount: 14
         ), 
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2))
      ],
    ),
         
  );
}
}

//URL
//https://pub.dev/packages/provider/install
//https://pub.dev/packages/http/install

//Tarea
//Poner el nombre del pokemon