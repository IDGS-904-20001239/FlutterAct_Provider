import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class UtilProvider extends ChangeNotifier{
  static final UtilProvider rtp = UtilProvider._();
  UtilProvider._();

  Future responsehttp({required String urlBase}) async {
    //Espera es la función de la variable wait
    var response = await http.get(Uri.parse(urlBase));
    return response;
  }
}